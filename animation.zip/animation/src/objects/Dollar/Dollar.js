import { Group } from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import MODEL from './Dollar.glb';

export default class Man extends Group {
  constructor() {
    const loader = new GLTFLoader();
    
    super();

    this.name = 'dollar';
    
    loader.load(MODEL,
     (gltf) => {
        gltf.scene.scale.set(0.3, 0.3, 0.3); 
        gltf.scene.position.set(-0.5,2,0.7);
        this.add(gltf.scene);
    }); 
  }
}
