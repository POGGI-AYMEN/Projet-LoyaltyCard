import { Group } from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import MODEL from './ok.glb';


export default class Man extends Group {
  constructor() {
    const loader = new GLTFLoader();
    
    super();

    this.name = 'qr';
    
    loader.load(MODEL,
     (gltf) => {
        gltf.scene.scale.set(0.1, 0.1, 0.1); 
        gltf.scene.position.set(0,2,-0.3);
        this.add(gltf.scene);
    }); 
  }
}
