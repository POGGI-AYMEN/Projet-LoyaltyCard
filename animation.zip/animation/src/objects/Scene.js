import { Group } from 'three';
import Land from './Land/Land.js';
import Man from './Man/Man.js';
import Dollar from './Dollar/Dollar.js';
import Qr from './Qr-code/Qr.js';
import BasicLights from './Lights.js';

export default class SeedScene extends Group {
  constructor() {
    super();

    const land = new Land();
    const man = new Man();
    const dollar = new Dollar();
    const qr = new Qr();
    const lights = new BasicLights();
    

    this.add(land, man, dollar, qr, lights);
  }

  update(timeStamp) {
    this.rotation.y = timeStamp / 1000;
  }
}